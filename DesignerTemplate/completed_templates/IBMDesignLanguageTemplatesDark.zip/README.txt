
Steps to add the templates to the designer :
1. Create the folder .vaadin/designer/templates in your home directory. (In Windows you need to use mkdir from command line).
2. Unzip the template files to the folder in step 1.
3. Create a new design in your project using the Vaadin eclipse plugin and make sure you import the styles also.

More complete tutorial on how to use templates: https://vaadin.com/wiki/-/wiki/Main/Using+templates+in+Vaadin+Designer